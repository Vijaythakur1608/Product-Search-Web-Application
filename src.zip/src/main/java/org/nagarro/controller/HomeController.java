package org.nagarro.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.nagarro.constants.Constant;
import org.nagarro.dao.TshirtDao;
import org.nagarro.dao.UserDao;
import org.nagarro.model.TshirtModel;
import org.nagarro.services.AppServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

	@Autowired
	private UserDao userDao;

	@Autowired
	private TshirtDao tshirtDao;

	AppServices service = new AppServices();

	@RequestMapping(value = "/login", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView checkUser(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView mv = new ModelAndView();

		String username = request.getParameter(Constant.username);
		String password = request.getParameter(Constant.password);

		if (service.authenticate(userDao, username, password)) {

			HttpSession session = request.getSession();
			session.setAttribute(Constant.username, username);
			mv.setViewName(Constant.product);
		} else {
			mv.setViewName(Constant.index);
		}

		return mv;
	}

	@RequestMapping(value = "/search", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView searchTshirt(Model m, HttpServletRequest request) {

		ModelAndView mv = new ModelAndView();

		HttpSession session = request.getSession();

		if (session.getAttribute(Constant.username) == null) {
			mv.setViewName(Constant.index);
			return mv;
		}

		String colour = request.getParameter(Constant.colour);
		String size = request.getParameter(Constant.size);
		String gender = request.getParameter(Constant.gender);
		int outputPreference = Integer.parseInt(request.getParameter(Constant.preference));

		ArrayList<TshirtModel> tshirtList = service.searchTshirt(tshirtDao, colour, size, gender, outputPreference);

		for (TshirtModel iter : tshirtList) {
			iter.getCompanyID();
		}

		m.addAttribute("tshirtList", tshirtList);
		mv.setViewName(Constant.product);

		return mv;
	}

	@RequestMapping(value = "/logout", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView logout(HttpServletRequest request) {

		ModelAndView mv = new ModelAndView();
		HttpSession session = request.getSession();
		session.setAttribute(Constant.username, null);
		mv.setViewName(Constant.index);

		return mv;

	}

}
