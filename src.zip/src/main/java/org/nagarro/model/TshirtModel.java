package org.nagarro.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class TshirtModel {

	@Id
	private String companyID;
	private String modelName;
	private String tshirtColour;
	private String genderRecomm;
	private String tshirtSize;
	private float tshirtPrice;
	private float tshirtRating;
	private String tshirtAvailability;

	public TshirtModel(String companyID, String modelName, String tshirtColour, String genderRecomm, String tshirtSize,
			float tshirtPrice, float tshirtRating, String tshirtAvailability) {

		this.companyID = companyID;
		this.modelName = modelName;
		this.tshirtColour = tshirtColour;
		this.genderRecomm = genderRecomm;
		this.tshirtSize = tshirtSize;
		this.tshirtPrice = tshirtPrice;
		this.tshirtRating = tshirtRating;
		this.tshirtAvailability = tshirtAvailability;
	}

	public TshirtModel() {

	}

	public String getCompanyID() {
		return companyID;
	}

	public void setCompanyID(String companyID) {
		this.companyID = companyID;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getTshirtColour() {
		return tshirtColour;
	}

	public void setTshirtColour(String tshirtColour) {
		this.tshirtColour = tshirtColour;
	}

	public String getGenderRecomm() {
		return genderRecomm;
	}

	public void setGenderRecomm(String genderRecomm) {
		this.genderRecomm = genderRecomm;
	}

	public String getTshirtSize() {
		return tshirtSize;
	}

	public void setTshirtSize(String tshirtSize) {
		this.tshirtSize = tshirtSize;
	}

	public float getTshirtPrice() {
		return tshirtPrice;
	}

	public void setTshirtPrice(float tshirtPrice) {
		this.tshirtPrice = tshirtPrice;
	}

	public float getTshirtRating() {
		return tshirtRating;
	}

	public void setTshirtRating(float tshirtRating) {
		this.tshirtRating = tshirtRating;
	}

	public String getTshirtAvailability() {
		return tshirtAvailability;
	}

	public void setTshirtAvailability(String tshirtAvailability) {
		this.tshirtAvailability = tshirtAvailability;
	}

}
