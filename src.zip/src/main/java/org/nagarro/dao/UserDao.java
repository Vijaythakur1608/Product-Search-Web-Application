package org.nagarro.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.nagarro.model.UserModel;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

@Component
public class UserDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Transactional
	public void saveToDatabase(UserModel userModel) {
		this.hibernateTemplate.save(userModel);
	}

	public List<UserModel> getUsers() {
		List<UserModel> list = this.hibernateTemplate.loadAll(UserModel.class);
		return list;
	}
}
