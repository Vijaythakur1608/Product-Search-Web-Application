package org.nagarro.dao;

import java.util.List;

import org.nagarro.model.TshirtModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

@Component
public class TshirtDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	public List<TshirtModel> getAllTshirt() {
		List<TshirtModel> tshirtList = this.hibernateTemplate.loadAll(TshirtModel.class);
		return tshirtList;

	}

}
