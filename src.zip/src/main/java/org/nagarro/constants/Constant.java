package org.nagarro.constants;

public class Constant {

	// Form elements....
	public final static String username = "username";
	public final static String password = "password";

	public final static String colour = "colour";
	public final static String gender = "gender";
	public final static String size = "size";
	public final static String preference = "preference";

	// View names....
	public final static String index = "index";
	public final static String product = "product";

}
