package org.nagarro.services;

import java.util.ArrayList;
import java.util.List;

import org.nagarro.dao.TshirtDao;
import org.nagarro.dao.UserDao;
import org.nagarro.model.TshirtModel;
import org.nagarro.model.UserModel;

public class AppServices {

	public boolean authenticate(UserDao userDao, String username, String password) {
		boolean result = false;

		List<UserModel> userList = userDao.getUsers();

		for (UserModel iter : userList) {
			if (iter.getUsername().equals(username) && iter.getPassword().equals(password)) {
				result = true;
			}
		}

		return result;
	}

	public ArrayList<TshirtModel> searchTshirt(TshirtDao tshirtDao, String colour, String size, String gender,
			int preference) {

		ArrayList<TshirtModel> resultList = new ArrayList<TshirtModel>();
		List<TshirtModel> tshirtList = tshirtDao.getAllTshirt();

		for (TshirtModel iter : tshirtList) {
			if (iter.getTshirtColour().equalsIgnoreCase(colour) && iter.getTshirtSize().equalsIgnoreCase(size)
					&& iter.getGenderRecomm().equalsIgnoreCase(gender)) {
				resultList.add(iter);
			}
		}
		return resultList;
	}

}
