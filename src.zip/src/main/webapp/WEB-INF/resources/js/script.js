function validateForm(){

  var error = 0;
  validSize = ["S","M","L","XL","XXL"];

  var colour = document.tshirtForm.colour.value;
  var size  = document.tshirtForm.size.value;
  var gender = document.tshirtForm.gender.value;
  var preference = document.tshirtForm.preference.value;

  if(colour==""){
    error++;
    document.getElementById("colour_error").innerHTML = "Colour must be filled";
  }

  let flag = false;
  for(var i = 0; i <validSize.length; i++){
    if(size.toUpperCase()==validSize[i]){
      flag = true;
    }
  }
  if(!flag){
    document.getElementById("size_error").innerHTML = "Enter the valid size";
    error++;
  }
  
  if(!(gender.toUpperCase()=="M" || gender.toUpperCase()=="F")){
	error++;
	document.getElementById("gender_error").innerHTML = "Enter the valid gender";
  }


  if(preference=="" || !(preference>0 && preference<3) || !(preference.isInteger())){
    error++;
    document.getElementById("prefer_error").innerHTML = "Enter the valid preference";
  }

  if(error>0) {
    return false;
  }
  return true;
}